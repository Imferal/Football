import './style.scss';

import soccer from './js/soccer';
soccer();